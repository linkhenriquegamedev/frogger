let imagemDaEstrada;
let imagemDoCarro;
let imagemDoCarro2;
let imagemDoCarro3;
let imagemDoAtor;

let trilha;
let colisao;
let ponto;

function preload(){
  imagemDaEstrada = loadImage('imagens/estrada.png');
  imagemDoCarro = loadImage('imagens/carro-1.png');
  imagemDoCarro2 = loadImage('imagens/carro-2.png');
  imagemDoCarro3 = loadImage('imagens/carro-3.png');
  imagemDoAtor = loadImage('imagens/ator-1.png');
  imagemCarros = [imagemDoCarro, imagemDoCarro2, imagemDoCarro3, imagemDoCarro, imagemDoCarro2, imagemDoCarro3];
  
  trilha = loadSound("sons/trilha.mp3");
  colisao = loadSound("sons/colidiu.mp3");
  pontos = loadSound("sons/pontos.wav");
}