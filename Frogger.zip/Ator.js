let yAtor = 366;
let xAtor = 100;
let bateuCarro = false;
let meusPontos = 0;


function mostraAtor(){
  image(imagemDoAtor, xAtor, yAtor, 30, 30);
}

function movimentaAtor(){
  if (keyIsDown(UP_ARROW)){
    yAtor -= 3;
  }
  
  if (keyIsDown(DOWN_ARROW)){
    if(estaBaixoDaCamera()){
         yAtor += 3;
       }
  }
}

function estaBaixoDaCamera(){
  return yAtor < 366;
}

function verificarColisao(){
  //collideLineCircle = function( x1,  y1,  x2,  y2,  cx,  cy,  diameter);
  for(let i = 0; i  < imagemCarros.length; i++){
    bateuCarro = collideRectCircle ( xCarros[i],  yCarros[i],  comprimentoCarro,  alturaCarro,  xAtor,  yAtor,  15);
    
    if(bateuCarro){
      voltaAtorAoPontoInicial();
      colisao.play();
      if(estaAcimaDeZero()){
           meusPontos = meusPontos - 1;
         }
    }
  }
}

function estaAcimaDeZero(){
  return meusPontos > 0;
}

function mostraPonto(){
  textAlign(CENTER);
  textSize(25);
  fill(color(255, 140, 60));
  text(meusPontos,  width / 5, 27);
}

function marcarPonto(){
  if(yAtor == 15){
    meusPontos++;
    pontos.play();
    voltaAtorAoPontoInicial();
  }
}


function voltaAtorAoPontoInicial(){
  yAtor = 366;
}